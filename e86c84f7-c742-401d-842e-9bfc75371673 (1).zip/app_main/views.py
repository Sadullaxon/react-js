from typing import Any
from django.db.models import Q
from django.shortcuts import redirect, render, get_object_or_404
from django.views.generic import ListView, CreateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import get_user_model
from django.urls import reverse, reverse_lazy
from django.utils.translation import gettext_lazy as _

from .models import Project, Tag
from .forms import ProjectForm, MessageForm


User = get_user_model()


class DevelopersView(ListView):
    template_name = 'app_main/developers.html'
    queryset = User.objects.exclude(
        Q(bio=None) | Q(occupation=None) | Q(location=None) |
        Q(bio='') | Q(occupation='') | Q(location='')
    )
    context_object_name = 'developers'


class ProjectCreate(LoginRequiredMixin, CreateView):
    login_url = reverse_lazy("login")
    model = Project
    template_name = 'app_main/project_form.html'
    form_class = ProjectForm
    extra_context = {
        'btn_text': 'Create project'
    }

    def get_success_url(self):
        return reverse('account', kwargs={'user_id': self.request.user.id})

    def dispatch(self, request, *args, **kwargs):
        if request.method == 'POST':
            tags = self.request.POST.get('tags', '').split(',')
            project_form = ProjectForm(self.request.POST)

            if project_form.is_valid():
                project = project_form.save(commit=False)
                project.owner = self.request.user
                project.save()

                # Process and add tags
                for tag_name in tags:
                    tag, created = Tag.objects.get_or_create(
                        name=tag_name.strip())
                    project.tags.add(tag.lower())

                project.save()  # Final save with tags
                return redirect("account", user_id=self.request.user.id)

            # If form is invalid, render the form with errors
            return redirect("project_create", kwargs={'user_id': self.request.user.id})

        return super().dispatch(request, *args, **kwargs)


class ProjectDetail(DetailView):
    model = Project
    pk_url_kwarg = 'project_id'
    template_name = 'app_main/project.html'


class ProfileView(DetailView):
    model = User
    pk_url_kwarg = 'user_id'
    template_name = 'app_main/profile.html'

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['dev_skills'] = self.get_object(
        ).skill_set.exclude(description="")
        context['other_skills'] = self.get_object(
        ).skill_set.filter(description="")
        return context


def handle_message_submission(request, receiver_id):
    # If POST, initialize form with POST data; otherwise, leave it empty for GET requests
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            
            if request.user.is_authenticated:
                message.sender = request.user
                message.fullname = request.user.fullname
                message.email = request.user.email
            
            # Retrieve the receiver user with error handling
            message.receiver = get_object_or_404(User, id=receiver_id)
            message.save()
            return redirect('profile_detail', user_id=receiver_id)
    
    form = MessageForm()

    # Adjust form fields for authenticated users in GET requests
    if request.user.is_authenticated:
        form.fields.pop('fullname', None)
        form.fields.pop('email', None)

    context = {
        'form': form,
        'btn_text': _('Send message')
    }
    return render(request, 'form.html', context)